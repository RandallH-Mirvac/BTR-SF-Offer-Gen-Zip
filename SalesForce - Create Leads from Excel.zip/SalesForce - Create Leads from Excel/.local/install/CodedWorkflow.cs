using System;
using System.Collections.Generic;
using System.Data;
using UiPath.CodedWorkflows;
using UiPath.Core;
using UiPath.Core.Activities.Storage;
using UiPath.Orchestrator.Client.Models;
using UiPath.UIAutomationNext.API.Contracts;
using UiPath.UIAutomationNext.API.Models;
using UiPath.UIAutomationNext.Enums;
using UiPath.CodedWorkflows.DescriptorIntegration;

namespace SalesForceCreateLeadsfromExcel
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{typeof(UiPath.Core.Activities.API.ISystemService), typeof(UiPath.UIAutomationNext.API.Contracts.IUiAutomationAppService)};
        }

        protected UiPath.Core.Activities.API.ISystemService system { get => serviceContainer.Resolve<UiPath.Core.Activities.API.ISystemService>(); }

        protected UiPath.UIAutomationNext.API.Contracts.IUiAutomationAppService uiAutomation { get => serviceContainer.Resolve<UiPath.UIAutomationNext.API.Contracts.IUiAutomationAppService>(); }
    }
}

namespace SalesForceCreateLeadsfromExcel.ObjectRepository
{
    public static class Descriptors
    {
        public static class Edge__Log_In_Using___Salesforce
        {
            public static _Implementation._Edge__Log_In_Using___Salesforce.__Edge__Log_In_Using___Salesforce Edge__Log_In_Using___Salesforce { get; private set; } = new _Implementation._Edge__Log_In_Using___Salesforce.__Edge__Log_In_Using___Salesforce();
        }

        public static class Edge__Log_In_Using___Salesforce_1_
        {
            public static _Implementation._Edge__Log_In_Using___Salesforce_1_.__Edge__Log_In_Using___Salesforce Edge__Log_In_Using___Salesforce { get; private set; } = new _Implementation._Edge__Log_In_Using___Salesforce_1_.__Edge__Log_In_Using___Salesforce();
        }

        public static class Edge__Log_In_Using___Salesforce_2_
        {
            public static _Implementation._Edge__Log_In_Using___Salesforce_2_.__Edge__Log_In_Using___Salesforce Edge__Log_In_Using___Salesforce { get; private set; } = new _Implementation._Edge__Log_In_Using___Salesforce_2_.__Edge__Log_In_Using___Salesforce();
        }

        public static class Edge__Log_In_Using___Salesforce_3_
        {
            public static _Implementation._Edge__Log_In_Using___Salesforce_3_.__Edge__Log_In_Using___Salesforce Edge__Log_In_Using___Salesforce { get; private set; } = new _Implementation._Edge__Log_In_Using___Salesforce_3_.__Edge__Log_In_Using___Salesforce();
        }

        public static class Edge__Log_In_Using___Salesforce_4_
        {
            public static _Implementation._Edge__Log_In_Using___Salesforce_4_.__Edge__Log_In_Using___Salesforce Edge__Log_In_Using___Salesforce { get; private set; } = new _Implementation._Edge__Log_In_Using___Salesforce_4_.__Edge__Log_In_Using___Salesforce();
        }
    }
}

namespace SalesForceCreateLeadsfromExcel._Implementation
{
    internal class ScreenDescriptorDefinition : IScreenDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }
    }

    internal class ElementDescriptorDefinition : IElementDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }

        public IElementDescriptor ParentElement { get; set; }

        public IElementDescriptor Element { get; set; }
    }

    namespace _Edge__Log_In_Using___Salesforce
    {
        public class __Edge__Log_In_Using___Salesforce : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Edge__Log_In_Using___Salesforce()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/bJAN7p6MGUm-RUA3eCwvGQ", DisplayName = "Edge: Log In Using | Salesforce", Screen = this};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class _____None__ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public _____None__(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/6MEHc3Q5M0GEnzJDYnS72w", DisplayName = "--None--", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Dr_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Dr_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/5F41Z8wHyUmtwMGpUiV5uw", DisplayName = "Dr.", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Dr__1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Dr__1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/rRuEnjr3P02GqJexXJYXcg", DisplayName = "Dr.(1)", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Mr_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Mr_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/9Nl2vNbx0ECxU8tltkib-A", DisplayName = "Mr.", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Mr__1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Mr__1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/X-ccDNyenk22foRtYma00A", DisplayName = "Mr.(1)", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Ms_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Ms_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/BGQnGIrj5EKY3ECFhAuGsg", DisplayName = "Ms.", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Ms__1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Ms__1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/Q-ZsXCUJy0iCTkXT1xO-XQ", DisplayName = "Ms.(1)", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Prof_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Prof_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/C0MgQen3r0CR9qQHKPi0KA", DisplayName = "Prof.", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Prof__1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Prof__1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/cthE-FMfFEKchmMXQF_JnA", DisplayName = "Prof.(1)", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Salutation : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Salutation(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/SZygyZFqEE6cqzZs9vJmdw", DisplayName = "Salutation", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce
    {
        public class __Salutation_1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Salutation_1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/_hXuujz3fEiBardXPLI_pA", DisplayName = "Salutation(1)", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_1_
    {
        public class __Edge__Log_In_Using___Salesforce : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Edge__Log_In_Using___Salesforce()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/qkBqmhg_gku6VAwg2Fhlew", DisplayName = "Edge: Log In Using | Salesforce", Screen = this};
                ___None__ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce._____None__(this, null);
                Dr_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Dr_(this, null);
                Dr__1_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Dr__1_(this, null);
                Mr_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Mr_(this, null);
                Mr__1_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Mr__1_(this, null);
                Ms_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Ms_(this, null);
                Ms__1_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Ms__1_(this, null);
                Prof_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Prof_(this, null);
                Prof__1_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Prof__1_(this, null);
                Salutation = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Salutation(this, null);
                Salutation_1_ = new _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Salutation_1_(this, null);
            }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce._____None__ ___None__ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Dr_ Dr_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Dr__1_ Dr__1_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Mr_ Mr_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Mr__1_ Mr__1_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Ms_ Ms_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Ms__1_ Ms__1_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Prof_ Prof_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Prof__1_ Prof__1_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Salutation Salutation { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_1_._Edge__Log_In_Using___Salesforce.__Salutation_1_ Salutation_1_ { get; private set; }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_2_._Edge__Log_In_Using___Salesforce
    {
        public class __Mr_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Mr_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/fE4usjIqHESYxftpUsdQVQ", DisplayName = "Mr.", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_2_._Edge__Log_In_Using___Salesforce
    {
        public class __Mr__1_ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Mr__1_(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/AOL3Ya2-LkmxQ7l6jEBrPA", DisplayName = "Mr.(1)", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_2_
    {
        public class __Edge__Log_In_Using___Salesforce : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Edge__Log_In_Using___Salesforce()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/XRUonkWqcEKWW5fHSBy_tA", DisplayName = "Edge: Log In Using | Salesforce", Screen = this};
                Mr_ = new _Implementation._Edge__Log_In_Using___Salesforce_2_._Edge__Log_In_Using___Salesforce.__Mr_(this, null);
                Mr__1_ = new _Implementation._Edge__Log_In_Using___Salesforce_2_._Edge__Log_In_Using___Salesforce.__Mr__1_(this, null);
            }

            public _Implementation._Edge__Log_In_Using___Salesforce_2_._Edge__Log_In_Using___Salesforce.__Mr_ Mr_ { get; private set; }

            public _Implementation._Edge__Log_In_Using___Salesforce_2_._Edge__Log_In_Using___Salesforce.__Mr__1_ Mr__1_ { get; private set; }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_3_._Edge__Log_In_Using___Salesforce
    {
        public class _____None__ : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public _____None__(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/mSN3ggJB2UialjktuEevXg", DisplayName = "--None--", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_3_
    {
        public class __Edge__Log_In_Using___Salesforce : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Edge__Log_In_Using___Salesforce()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/l3cMluv6X0WA-BYK6f2sTQ", DisplayName = "Edge: Log In Using | Salesforce", Screen = this};
                ___None__ = new _Implementation._Edge__Log_In_Using___Salesforce_3_._Edge__Log_In_Using___Salesforce._____None__(this, null);
            }

            public _Implementation._Edge__Log_In_Using___Salesforce_3_._Edge__Log_In_Using___Salesforce._____None__ ___None__ { get; private set; }
        }
    }

    namespace _Edge__Log_In_Using___Salesforce_4_
    {
        public class __Edge__Log_In_Using___Salesforce : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Edge__Log_In_Using___Salesforce()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "VTZjCKVv2UK6UWYH6IR8jA/JYre_N7_ukKvdQYKoYqSgg", DisplayName = "Edge: Log In Using | Salesforce", Screen = this};
            }
        }
    }
}